#ifndef modeC_included
#define modeC_included

void modeC(void);

#endif
