#ifndef bundle_included
#define bundle_included

void checkNull(void *);

#endif
