#ifndef sort_included
#define sort_included

#include "solver.h"

void MergeSort(TreeNode**);

#endif
