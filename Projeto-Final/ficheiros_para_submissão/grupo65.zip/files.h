#ifndef files_included
#define files_included

void initFile(const char *);
void maxSize(void);
void begining(void);
int reachedEOF(void);
int readFile(void);
void writeFile(void);
void terminateFile(void);

#endif
