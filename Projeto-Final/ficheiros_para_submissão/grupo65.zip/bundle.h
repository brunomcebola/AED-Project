#ifndef bundle_included
#define bundle_included

void checkNull(int num, ...);

#endif
