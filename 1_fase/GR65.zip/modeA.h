#ifndef modeA_included
#define modeA_included

void modeA(void);

#endif
