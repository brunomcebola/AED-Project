#ifndef modeB_included
#define modeB_included

void modeB(void);

#endif
